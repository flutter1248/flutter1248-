import datetime
# todo, train yolo with 2 classes
# todo, use yolo with pytorch instead of OPENCV Dnn
# todo, dont read frames in main  process
# todo, TensrorRT with onnx?
# todo, face align, face landmarkrks in Rest api arc?
# todo, All api endpoits be async ?
# todo, fOR CACHEHE USE REDIS
# todo, enforce constant FPS
# todo, try changing mean and std to see effect on ccuracy
# todo, dividing bt mean and std as in Insightface
# todo, facial landmarks are [5:15] in f2.onnx
# todo, yoloface is f2.onnx, can convert it 16bit prec onnx
# todo, Use portrait resolution instead of 320x320
# todo, wassup with with class probabilities, do we even need them?
# todo, for detection use scrfd or blazeface or https://github.com/SthPhoenix/InsightFace-REST yolov5face
import cv2
import jsonpickle
import requests
from numpy.linalg import norm
import os
import warnings
from line_profiler_pycharm import profile

warnings.simplefilter(action='ignore', category=FutureWarning)
import pandas as pd
from scipy.spatial.distance import cosine
from typing import List, Optional, Union
import torch
import norfair
from norfair import Detection, Paths, Tracker, Video, OptimizedKalmanFilterFactory, get_cutout
from norfair.distances import frobenius, iou
from numpy import asarray
import time
import numpy as np
import onnxruntime as ort

# import insightface
# handler = insightface.model_zoo.get_model(r'w600k_r50.onnx')
# handler.session.set_providers([ 'CUDAExecutionProvider'])
# handler.prepare(ctx_id=0, input_size=(224, 224, 3))

distance_function = iou
distance_threshold = 0.7

BASE_PATH = os.getcwd()




ort_sess2 = ort.InferenceSession('./OCR/models/f2.onnx',
                                 providers=
                                 # ['TensorrtExecutionProvider'], options=({
        # 'trt_fp16_enable': True,
        # 'trt_dla_enable': True
    #
    # })
                                 # ['TensorrtExecutionProvider'],
                                 ['CUDAExecutionProvider'],
                                 # ['CPUExecutionProvider'],
                                 )

ort_sess = ort.InferenceSession('./OCR/models/yolov5m_dynamic.onnx',
                                providers=
                                # ['TensorrtExecutionProvider'], options=({
        # 'trt_fp16_enable': True,
        # 'trt_dla_enable': True
    #
    # })
                                # ['TensorrtExecutionProvider'],
                                ['CUDAExecutionProvider'],
                                # ['CPUExecutionProvider'],
                                )

ort_sess_r = ort.InferenceSession(r'./OCR/models/glintr100.onnx',
                                  providers=
                                  # ['TensorrtExecutionProvider'], options = ({
        # 'trt_fp16_enable': True,
        # 'trt_dla_enable': True
    #
    # })
                                  # ['TensorrtExecutionProvider'],
                                  ['CUDAExecutionProvider'],
                                  # ['CPUExecutionProvider'],
                                  )


class Person:

    def __init__(self, det_time, exit_time, duration, det_history, person_name,
                 person_id, status='', f=None, p=None):
        if p is None:
            p = list()
        if f is None:
            f = list()
        self.det_time = det_time
        self.exit_time = exit_time
        self.duration = duration
        self.det_history = det_history
        self.person_name = person_name
        self.person_id = person_id
        self.status = status
        self.det_face: list = f
        self.det_person: list = p

    def details(self):
        return 3


debug = False


class Detections:

    def __init__(self, wf, hf, wp, hp):
        self.WIDTH_FACE = wf
        self.HEIGHT_FACE = hf
        self.WIDTH_PERSON = wp
        self.HEIGHT_PERSON = hp
        self.person_list = []

    @profile
    def get_detections(self, img):
        start_time = time.perf_counter()
        image = img.copy()
        # image = cv2.imread(r'E:\pytorch-flask-api\OCR\data2\alamzeb.JPG')
        row, col, d = image.shape

        max_rc = max(row, col)
        input_image = np.zeros((max_rc, max_rc, 3), dtype=np.uint8)
        input_image[0:row, 0:col] = image

        blob = cv2.dnn.blobFromImage(input_image, 1 / 255, (self.WIDTH_FACE, self.HEIGHT_FACE), swapRB=True, crop=False)
        # blob2 = blob.astype(np.float16)
        blob2 = blob
        # res = asyncio.run(asyn(blob,blob2))
        # preds = res[0]
        # preds_f = res[1]
# 238376

        preds = ort_sess.run(None, {'images': blob2})
        preds_f = ort_sess2.run(None, {'input': blob})  # 438901
        # preds = net.forward()
        # preds_f = net2.forward()
        detections = preds[0][0]
        detections_f = preds_f[0][0]
        end_time = time.perf_counter()
        if debug:
            print('det', end_time - start_time)
        return input_image, detections, detections_f

    @profile
    def non_maximum_supression(self, input_image, detections_f, detections, c=0.25, pf=0.6, pp=0.6, str=""):
        start_time = time.perf_counter()

        index_face = cv2.dnn.NMSBoxes(detections_f[:, :4].tolist(), detections_f[:, 4].tolist(), pf, c)
        index_person = cv2.dnn.NMSBoxes(detections[:, :4].tolist(), detections[:, 4].tolist(), pp, c)
        end_time = time.perf_counter()
        if debug:
            print('nms: ', end_time - start_time)
        return index_face, index_person

    @profile
    def extract_text(self, image, bboxes, bboxes_p, tracker):
        # return image
        start_time = time.perf_counter()
        # global df
        # global names
        scale = image.shape[1] / 320
        if len(bboxes_p) < 1: return image
        bboxes_p[:, 2] = bboxes_p[:, 2] - bboxes_p[:, 0]
        bboxes_p[:, 3] = bboxes_p[:, 3] - bboxes_p[:, 1]
        d = bboxes_p[:, :4] * scale
        bboxes_p = np.hstack([d, bboxes_p[:, 4].reshape([-1, 1])])
        # import matplotlib.pyplot as plt;plt.imshow(image[y1:y2,x1:x2]); plt.show()
        bboxes_p = bboxes_p.astype(np.int32)
        if len(bboxes) > 0:
            bboxes[:, 2] = bboxes[:, 2] - bboxes[:, 0]
            bboxes[:, 3] = bboxes[:, 3] - bboxes[:, 1]
            bboxes = bboxes[:, :4] * scale
            bboxes = bboxes.astype(np.int32)
        # df = pd.DataFrame({'PersonName': [], 'DateTime': [],'Camera': []})
        detections = yolo_detections_to_norfair_detections(
            bboxes_p, track_points='bbox'
        )
        # bboxes_p = bboxes_p[:3]
        for detection in detections:
            cut = get_cutout(detection.points, image)
            if cut.shape[0] > 0 and cut.shape[1] > 0:
                detection.embedding = get_hist(cut)
            else:
                detection.embedding = None
        tracked_objects = tracker.update(detections=detections)
        if tracked_objects:
            pass
            # x = [i for i in tracked_objects if tracked_objects.age>50]

        for x in tracked_objects:
            found = False
            for p in self.person_list:
                if len(self.person_list) > 0 and x.id == p.person_id:
                    if x.id == p.person_id:
                        # todo, update tracker state with object
                        found = True
                        p.det_person = np.array([*x.last_detection.points[0], *x.last_detection.points[1]])
                        z = p.det_person
                        # todo fix bboxes first, add threshold, also minmax issue?
                        a = [iouc(xywh2x1y1x2y2(i), z) for i in bboxes]
                        if a:
                            if not all(max(a) == 0):
                                index = np.argmax(a)
                                # todo , fix this too
                                # print('ddddddddddddddddddddddddddddddddddd', index)

                                p.det_face = bboxes[index]
                            else:
                                p.det_face = []
                        else:
                            p.det_face = []

            if not found:
                d = Person(datetime.datetime.now(), datetime.datetime.now(), 0, 3, 'na', x.id)
                d.status = 'An unidentified person has appeared in camera'

                test_url = 'http://localhost:5001/api'
                headers = {'content-type': 'image/jpeg'}
                # category, person_name, img = getImages()
                # img = cv2.imread(r'E:\pytorch-flask-api\OCR\data2\imran2.PNG')
                # _, img_encoded = cv2.imencode('.jpg', img)
                body = jsonpickle.encode({'findings': d.status})
                response = requests.post(test_url, data=body, headers=headers)

                d.det_person = np.array([*x.last_detection.points[0], *x.last_detection.points[1]])
                z = d.det_person
                a = [iouc(xywh2x1y1x2y2(i), z) for i in bboxes]
                if a:
                    index = np.argmax(a)
                    # todo , fix this too
                    # print('ddddddddddddddddddddddddddddddddddd',index )
                    d.det_face = bboxes[index]
                else:
                    d.det_face = []
                # d.det_face = None
                self.person_list.append(d)

        # dead,  also person has left the scene
        for i, p in enumerate(self.person_list):
            found = False
            for x in tracked_objects:
                if len(tracked_objects) > 0:
                    if x.id == p.person_id:
                        found = True
            if not found:
                self.person_list[i].status = 'Person has left the scene'
                self.person_list.remove(p)

        try:
            if len(self.person_list) > 0:
                images = []
                batch = []

                for bb in self.person_list:
                    if len(bb.det_face) > 0:
                        # x1, y1, x2, y2 = bb.det_face
                        x1, y1, width, height = bb.det_face
                        x2, y2 = x1 + width, y1 + height
                        images.append(image[y1:y2, x1:x2])

                for x in images:
                    img = cv2.resize(x, (112, 112))
                    img = img.reshape(1, 112, 112, 3)
                    # img = np.transpose(img, (0, 3, 1, 2))
                    samples = np.asarray(img, 'float32')
                    blob = cv2.dnn.blobFromImage(samples[0], 1 / 255, (112, 112), swapRB=True)

                    # img = cv2.resize(x, (224, 224))
                    # img = img.reshape(1, 224, 224, 3)
                    # samples = np.asarray(img, 'float32')
                    # samples = preprocess_input(samples, version=2)
                    batch = np.append(batch, blob, axis=0) if len(batch) > 0 else np.array(blob)

                # pred = model(batch)  # 61.3
                if len(batch) > 0:
                    pred = ort_sess_r.run(None, {'input.1': batch})

                    # todo, change this too
                    users = {"imran": imran, "Shahmeer": Shahmeer, "Ismail": Ismail, "Haris": Haris,
                             "Ameer_Hamza": Ameer_Hamza,
                             "umer": umer, "gate_keeper": gate_keeper, 'Usman': Usman,
                             'ahsan': ahsan, "ajmal": ajmal, 'amir': amir, "bilal": bilal, 'Waqas': Waqas,
                             'alamzeb': alamzeb, 'faiz': faiz, 'farhan': farhan, 'uzair': uzair, 'hassan': hassan,
                             'sindbad': sindbad,
                             'kashif': kashif, 'khalid': khalid, 'murad': murad, 'noman': noman, 'salman': salman,
                             'tanvir': tanvir,
                             'zulfiqar': zulfiqar
                             }
                    # scores = [{x: cosine(p, y[0]) for x, y in users.items()} for p in pred[0]]  # 25.8
                    scores = [{x: compute_sim(p, y[0]) for x, y in users.items()} for p in pred[0]]

                    names = []
                    for emb in scores:
                        data = {x: y for x, y in emb.items() if y == max(emb.values()) and y > 0.30}
                        if len(data) > 0:
                            names.append([*data][0])
                        else:
                            names.append("na")
                    # print('names--------------------cc : ', names)
                    for bb, n in zip(self.person_list, names):
                        if len(bb.det_face) > 0:
                            if n != 'na':
                                bb.person_name = n
                            x, y, w, h = bb.det_face
                            # print('name: ', bb.person_name)
                            # print('name_______N: ', n)
                            if bb.person_name != 'na':

                                color = (255, 0, 0)
                            else:
                                color = (255, 0, 255)
                            cv2.rectangle(image, (x, y), (x + w, y + h), color, 2)
                            cv2.rectangle(image, (x, y - 30), (x + w, y), color, -1)
                            cv2.rectangle(image, (x, y + h), (x + w, y + h + 30), (0, 0, 0), -1)
                            # cv2.putText(image, conf_text, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 1)
                            cv2.putText(image, bb.person_name, (x, y + h + 27), cv2.FONT_HERSHEY_SIMPLEX, 0.7,
                                        (0, 255, 0), 1)

            else:
                pass

        except BaseException as e:
            print('eeeeeeeeeeeeeeeeeeeeeeeeeeeeeexception')
            print(e, e.__traceback__.tb_lineno)


        # try:
        #     if len(bboxes) > 0:
        #         images = []
        #         batch = []
        #         for bb in bboxes:
        #             x1, y1, width, height = bb
        #             x2, y2 = x1 + width, y1 + height
        #             images.append(image[y1:y2, x1:x2])
        #
        #         for x in images:
        #             img = cv2.resize(x, (112, 112))
        #             img = img.reshape(1, 112, 112, 3)
        #             # img = np.transpose(img, (0, 3, 1, 2))
        #             samples = np.asarray(img, 'float32')
        #             blob = cv2.dnn.blobFromImage(samples[0], 1 / 255, (112, 112), swapRB=True)
        #
        #             # img = cv2.resize(x, (224, 224))
        #             # img = img.reshape(1, 224, 224, 3)
        #             # samples = np.asarray(img, 'float32')
        #             # samples = preprocess_input(samples, version=2)
        #             batch = np.append(batch, blob, axis=0) if len(batch) > 0 else np.array(blob)
        #
        #         # pred = model(batch)  # 61.3
        #         pred = ort_sess_r.run(None, {'input.1': batch})
        #
        #         # todo, change this too
        #         users = {"imran": imran, "Shahmeer": Shahmeer, "Ismail": Ismail, "Haris": Haris,
        #                  "Ameer_Hamza": Ameer_Hamza,
        #                  "umer": umer, "gate_keeper": gate_keeper, 'Usman': Usman,
        #                  'ahsan': ahsan, "ajmal": ajmal, 'amir': amir, "bilal": bilal, 'Waqas': Waqas,
        #                  'alamzeb': alamzeb, 'faiz': faiz, 'farhan': farhan, 'uzair': uzair, 'hassan': hassan,
        #                  'sindbad': sindbad,
        #                  'kashif': kashif, 'khalid': khalid, 'murad': murad, 'noman': noman, 'salman': salman,
        #                  'tanvir': tanvir,
        #                  'zulfiqar': zulfiqar
        #                  }
        #         # scores = [{x: cosine(p, y[0]) for x, y in users.items()} for p in pred[0]]  # 25.8
        #         scores = [{x: compute_sim(p, y[0]) for x, y in users.items()} for p in pred[0]]
        #
        #         names = []
        #         for emb in scores:
        #             data = {x: y for x, y in emb.items() if y == max(emb.values()) and y > 0.33}
        #             if len(data) > 0:
        #                 names.append([*data][0])
        #             else:
        #                 names.append("anonymous")
        #
        #         # df = pd.DataFrame({'PersonName': [], 'DateTime': [], 'Camera': []})
        #
        #         # person entered the scene
        #         # for x in tracked_objects:
        #         #     found = False
        #         #     for p in self.person_list:
        #         #         if len(self.person_list) > 0:
        #         #             if x.id == p.person_id:
        #         #                 # todo, update tracker state with object
        #         #                 found = True
        #         #     if not found:
        #         #         d = Person(datetime.datetime.now(), datetime.datetime.now(), 0, 3, 'na', x.id)
        #         #         d.status = 'An unidentified person has appeared in camera'
        #         #         d.det_person = np.array([*x.last_detection.points[0], *x.last_detection.points[1]])
        #         #         z = d.det_person
        #         #         index = np.argmax([iouc(xywh2x1y1x2y2(i), z) for i in bboxes])
        #         #         d.det_face = bboxes[index]
        #         #         # d.det_face = None
        #         #         self.person_list.append(d)
        #         #
        #         # # dead,  also person has left the scene
        #         # for i, p in enumerate(self.person_list):
        #         #     found = False
        #         #     for x in tracked_objects:
        #         #         if len(tracked_objects) > 0:
        #         #             if x.id == p.person_id:
        #         #                 found = True
        #         #     if not found:
        #         #         self.person_list[i].status = 'Person has left the scene'
        #         #         self.person_list.remove(i)
        #
        #         # for bx, name in zip(bboxes, names):
        #         #     # df = df.append(
        #         #     #     {'PersonName': name, 'DateTime': datetime.datetime.now().strftime("%m/%d/%Y, %I:%M:%S"),
        #         #     #      'Camera': '1'}, ignore_index=True)
        #         #     x, y, w, h = bx
        #         #
        #         #     z = xywh2x1y1x2y2(bx)
        #         #     index = np.argmax([iouc(xywh2x1y1x2y2(i), z) for i in bboxes_p])
        #         #
        #         #     # if tracked_objects[index].name is None:
        #         #     #     p.id = name
        #         #     # elif tracked_objects[index].name != name and tracked_objects[index].name != 'na':
        #         #     #     tracked_objects[index].name = name
        #         #     # else:
        #         #     #     tracked_objects[index].name = 'compromised'
        #         #
        #         #     # bb_conf = conf
        #         #     # conf_text = 'Name: {:.0f}%'.format(bb_conf * 100)
        #         #     if name != 'na':
        #         #         color = (255, 0, 0)
        #         #     else:
        #         #         color = (255, 0, 255)
        #         #     cv2.rectangle(image, (x, y), (x + w, y + h), color, 2)
        #         #     cv2.rectangle(image, (x, y - 30), (x + w, y), color, -1)
        #         #     cv2.rectangle(image, (x, y + h), (x + w, y + h + 30), (0, 0, 0), -1)
        #         #     # cv2.putText(image, conf_text, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 1)
        #         #     cv2.putText(image, name, (x, y + h + 27), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 1)
        #
        #         for bx, name in zip(bboxes, names):
        #             # df = df.append(
        #             #     {'PersonName': name, 'DateTime': datetime.datetime.now().strftime("%m/%d/%Y, %I:%M:%S"),
        #             #      'Camera': '1'}, ignore_index=True)
        #             x, y, w, h = bx
        #
        #             # z = xywh2x1y1x2y2(bx)
        #             # index = np.argmax([iouc(xywh2x1y1x2y2(i), z) for i in bboxes_p])
        #
        #             # if tracked_objects[index].name is None:
        #             #     p.id = name
        #             # elif tracked_objects[index].name != name and tracked_objects[index].name != 'na':
        #             #     tracked_objects[index].name = name
        #             # else:
        #             #     tracked_objects[index].name = 'compromised'
        #
        #             # bb_conf = conf
        #             # conf_text = 'Name: {:.0f}%'.format(bb_conf * 100)
        #             if name != 'na':
        #                 color = (255, 0, 0)
        #             else:
        #                 color = (255, 0, 255)
        #             cv2.rectangle(image, (x, y), (x + w, y + h), color, 2)
        #             cv2.rectangle(image, (x, y - 30), (x + w, y), color, -1)
        #             cv2.rectangle(image, (x, y + h), (x + w, y + h + 30), (0, 0, 0), -1)
        #             # cv2.putText(image, conf_text, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 1)
        #             cv2.putText(image, name, (x, y + h + 27), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 1)
        #         # norfair.draw_tracked_boxes(image, tracked_objects)
        #     else:
        #         pass  # df = pd.DataFrame({'PersonName': [], 'DateTime': [], 'Camera': []})

        # except BaseException as e:
        #     print(e, e.__traceback__.tb_lineno)
        norfair.draw_tracked_boxes(image, tracked_objects, draw_labels=True)
        end_time = time.perf_counter()
        if debug:
            print('recog: ', end_time - start_time)
        return image

    @profile
    def yolo_predictions(self, frame, tracker):
        start_time = time.perf_counter()
        # global net  # 52, 40, 7.8
        # global net2
        # global frames
        frames = frame
        input_image, detections, detections_f = self.get_detections(frames)
        detections = detections[detections[:, 5] >= 0.90]

        indF = cv2.dnn.NMSBoxes(detections_f[:, :4].tolist(), detections_f[:, 4].tolist(), 0.6, 0.4)
        indP = cv2.dnn.NMSBoxes(detections[:, :4].tolist(), detections[:, 4].tolist(), 0.40, 0.4)

        # indF,indP= non_maximum_supression(input_image, detections_f, detections)

        # boxes_P = nms(detections.astype(np.float64), 0.4, 0.4)
        # boxes_F = nms(detections_f, 0.4, 0.4)

        #det 18.7 ms





        if len(indF) > 0:
            indF = xywh2xyxy(detections_f[indF][:, :4])
        else:
            indF = np.array([])
        if len(indP) > 0:
            indP = xywh2xyxy(detections[indP][:, :5])
        else:
            indP = np.array([])

        # result_img = extract_text(frames, boxes_np, confidences_np, index, boxes_np_p, confidences_np_p, index_p)
        # result_img = extract_text(input_image, boxes_F, input_image, input_image, boxes_P, input_image, input_image)
        result_img = self.extract_text(frames, indF, indP, tracker)
        # result_img = extract_text(frame, boxes_F, boxes_P)
        end_time = time.perf_counter()

        if debug:
            print('loop: ', end_time - start_time)
        return result_img


# INPUT_WIDTH = 320
# INPUT_HEIGHT = 320
# INPUT_WIDTH2 = 320
# INPUT_HEIGHT2 = 320
# DISTANCE_THRESHOLD_BBOX: float = 0.7
# MAX_DISTANCE: int = 10000

#############
# names = []
# frames = []
############
# df = pd.DataFrame({'PersonName': [], 'DateTime': []})


@profile
def embedding_distance(matched_not_init_trackers, unmatched_trackers):
    snd_embedding = unmatched_trackers.last_detection.embedding

    if snd_embedding is None:
        for detection in reversed(unmatched_trackers.past_detections):
            if detection.embedding is not None:
                snd_embedding = detection.embedding
                break
        else:
            return 1

    for detection_fst in matched_not_init_trackers.past_detections:
        if detection_fst.embedding is None:
            continue

        distance = 1 - cv2.compareHist(
            snd_embedding, detection_fst.embedding, cv2.HISTCMP_CORREL
        )
        if distance < 0.5:
            return distance
    return 1


# x1,y1,x2,y2 = p.det_person
# import matplotlib.pyplot as plt;plt.imshow(image[y1:y2,x1:x2]); plt.show()

# x1,y1,x2,y2 = p.det_face
# import matplotlib.pyplot as plt;plt.imshow(image[y1:y2+y1,x1:x2+x1]); plt.show()


def iouc(bboxes1, bboxes2):
    x11, y11, x12, y12 = np.split(bboxes1, 4, axis=0)
    x21, y21, x22, y22 = np.split(bboxes2, 4, axis=0)
    xA = np.maximum(x11, np.transpose(x21))
    yA = np.maximum(y11, np.transpose(y21))
    xB = np.minimum(x12, np.transpose(x22))
    yB = np.minimum(y12, np.transpose(y22))
    interArea = np.maximum((xB - xA + 1), 0) * np.maximum((yB - yA + 1), 0)
    boxAArea = (x12 - x11 + 1) * (y12 - y11 + 1)
    boxBArea = (x22 - x21 + 1) * (y22 - y21 + 1)
    iou = interArea / (boxAArea + np.transpose(boxBArea) - interArea)
    return iou


# [iouc(x,y) for (x,y) in e]
# e = zip(np.array([bboxes[0] for t in range(len(bboxes_p))]),bboxes_p[:,:4])

def xywh2xyxy(x):
    # Convert nx4 boxes from [x, y, w, h] to [x1, y1, x2, y2] where xy1=top-left, xy2=bottom-right
    x[:, 0] = x[:, 0] - x[:, 2] / 2  # top left x
    x[:, 1] = x[:, 1] - x[:, 3] / 2  # top left y
    # x[:, 2] = x[:, 2]  # bottom right x
    # x[:, 3] = x[:, 3]  # bottom right y
    x[:, 2] = x[:, 0] + x[:, 2]  # bottom right x
    x[:, 3] = x[:, 1] + x[:, 3]  # bottom right y
    return x


def xywh2x1y1x2y2(x):
    y = np.copy(x[:4])
    y[2] = y[0] + y[2]  # bottom right x
    y[3] = y[1] + y[3]  # bottom right y
    return y


def yolo_detections_to_norfair_detections(
        yolo_detections: torch.tensor, track_points: str = "bbox"
) -> List[Detection]:
    norfair_detections: List[Detection] = []
    for detection_as_xyxy in yolo_detections:
        bbox = np.array(
            [
                [detection_as_xyxy[0], detection_as_xyxy[1]],
                [detection_as_xyxy[0] + detection_as_xyxy[2]
                    , detection_as_xyxy[1] + detection_as_xyxy[3]],
            ]
        )
        norfair_detections.append(
            Detection(
                points=bbox,
            )
        )
    return norfair_detections


d = Detections(320, 320, 320, 320)


def getEmbed(file):
    img = cv2.imread(file)
    i, _, detections_f = d.get_detections(img)
    indF, indP = d.non_maximum_supression(i, detections_f, _)
    # if len(indF) < 1:
    #     boxes_np, confidences_np, index, _, _, _ = non_maximum_supression(i, detections_f, results, c=0.15, pp=1,
    #                                                                       pf=0.14, str=file)
    boxes_np = xywh2xyxy(detections_f[indF][:, :4])

    boxes_np[:, 2] = boxes_np[:, 2] - boxes_np[:, 0]
    boxes_np[:, 3] = boxes_np[:, 3] - boxes_np[:, 1]
    scale = i.shape[1] / 320
    boxes_np = boxes_np * scale
    image = boxes_np[0].astype(np.int32)
    print(file)
    x1, y1, width, height = image
    if x1 < 0: x1 = 0
    if y1 < 0: y1 = 0
    x2, y2 = x1 + width, y1 + height
    face = img[y1:y2, x1:x2]
    # images = cv2.resize(face, (224, 224))
    # images = images.reshape(1, 224, 224, 3)
    images = cv2.resize(face, (112, 112))
    images = images.reshape(1, 112, 112, 3)
    # images = np.transpose(images, (0, 3, 1, 2))
    samples = asarray(images, 'float32')
    # TODO, 1/127.5 for std and mean(127.5,,)
    blob = cv2.dnn.blobFromImage(samples[0], 1.0 / 255, (112, 112), swapRB=True)

    # samples = preprocess_input(samples, version=2)
    pred = ort_sess_r.run(None, {'input.1': blob})
    # pred = model(samples)
    return pred[0]


imran = getEmbed(file=r"./OCR\data2\imran2.PNG")
Ameer_Hamza = getEmbed(file=r"./OCR\data2\Ameer_Hamza.jpg")
Haris = getEmbed(file=r"./OCR\data2\Haris.jpg")
Ismail = getEmbed(file=r"./OCR\data2\Ismail.jpg")
Shahmeer = getEmbed(file=r"./OCR\data2\Shahmeer.jpg")
umer = getEmbed(file=r"./OCR\data2\umer2.PNG")
gate_keeper = getEmbed(file=r"./OCR\data2\gatekeeper.jpeg")
Usman = getEmbed(file=r"./OCR\data2\Usman1.jpg")
ahsan = getEmbed(file=r"./OCR\data2\IMG_5607.JPG")
ajmal = getEmbed(file=r"./OCR\data2\IMG_5619.JPG")
amir = getEmbed(file=r"./OCR\data2\amir1.JPG")
bilal = getEmbed(file=r"./OCR\data2\IMG_5597.JPG")
Waqas = getEmbed(file=r"./OCR\data2\waqas.jpeg")
alamzeb = getEmbed(file=r"./OCR\data2\alamzeb.jpg")
faiz = getEmbed(file=r"./OCR\data2\faiz.jpg")
farhan = getEmbed(file=r"./OCR\data2\farhan.jpg")
uzair = getEmbed(file=r"./OCR\data2\uzair.jpg")
hassan = getEmbed(file=r"./OCR\data2\hassan.jpg")
sindbad = getEmbed(file=r"./OCR\data2\sindbad.jpg")
kashif = getEmbed(file=r"./OCR\data2\kashif1.JPG")
khalid = getEmbed(file=r"./OCR\data2\khalid.JPG")
murad = getEmbed(file=r"./OCR\data2\Murad.JPG")
noman = getEmbed(file=r"./OCR\data2\noman.JPG")
salman = getEmbed(file=r"./OCR\data2\salman.JPG")
tanvir = getEmbed(file=r"./OCR\data2\tanvir5.JPG")
zulfiqar = getEmbed(file=r"./OCR\data2\zulfiqar.JPG")


# vw = cv2.VideoWriter(filename="video33.mp4",
#                     fourcc=cv2.VideoWriter_fourcc(*'mp4v'),
#                     fps=20,
#                     # fps=int(video.get(cv2.CAP_PROP_FPS)),
#                     frameSize=(1920 ,1080))


def compute_sim(feat1, feat2):
    # feat1 = feat1.ravel()
    # feat2 = feat2.ravel()
    sim = np.dot(feat1, feat2) / (norm(feat1) * norm(feat2))
    return sim


# import matplotlib.pyplot as plt; plt.imshow(image[bboxes[0][0]:bboxes[0][0]+bboxes[0][2],bboxes[0][1]:bboxes[0][1]+bboxes[0][3]]);plt.show()
def get_hist(image):
    hist = cv2.calcHist(
        [cv2.cvtColor(image, cv2.COLOR_BGR2Lab)],
        [0, 1],
        None,
        [128, 128],
        [0, 256, 0, 256],
    )
    return cv2.normalize(hist, hist).flatten()


def getDataFromFrame():
    global df
    return df


def getImages():
    global frames
    global names
    return 'anonymous/whitelist', names, frames
