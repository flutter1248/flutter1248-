import datetime
# import tensorflow as tf

# tf.config.set_visible_devices([],'GPU')
import time

from line_profiler_pycharm import profile
from waitress import serve
from flask import Flask, request, jsonify, render_template, Response
from flask_cors import CORS

from OCR.face import getDataFromFrame, getImages, embedding_distance, Detections
import os
import cv2
import requests
import pandas as pd
import jsonpickle
import numpy as np
import cv2
import requests
import json

from norfair import OptimizedKalmanFilterFactory, Tracker

app = Flask(__name__)
cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'
BASE_PATH = os.getcwd()
UPLOAD_PATH = os.path.join(BASE_PATH, 'static/upload')
os.path.exists(BASE_PATH)



# client
@app.route('/archiving', methods=['POST', 'GET'])
def archive_data():
    test_url = 'http://localhost:5001/'
    headers = {'content-type': 'image/jpeg'}
    category, person_name, img = getImages()
    # img = cv2.imread(r'E:\pytorch-flask-api\OCR\data2\imran2.PNG')
    _, img_encoded = cv2.imencode('.jpg', img)
    body = jsonpickle.encode({'cam_id_req': '4568ErrtFLli3s298zZVv',
                              'cam_id': 1,
                              'findings': category,
                              'personname': person_name,
                              'datetime': datetime.datetime.now().isoformat(),
                              'fileToUpload': img_encoded.tobytes()})
    response = requests.post(test_url, data=body, headers=headers)

    return json.loads(response.text)


# server
# app = Flask(__name__)
# @app.route('/api/test', methods=['POST'])
# def test():
#     r = request
#     # convert string of image data to uint8
#     nparr = np.frombuffer(r.data, np.uint8)
#     # decode image
#     img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
#     # build a response dict to send back to client
#     response = {'message': 'image received. size={}x{}'.format(img.shape[1], img.shape[0])}
#     response = {'message': 234}
#     # encode response using jsonpickle
#     response_pickled = jsonpickle.encode(response)
#     return Response(response=response_pickled, status=200, mimetype="application/json")
# app.run(host="0.0.0.0", port=5000)


@app.route('/getdata', methods=['GET'])
def data():
    df = getDataFromFrame()
    print("pritning again")
    print(df)
    return df.to_json()
    # return jsonify({'name': 'name',
    #                 'address': 'address'})


# import the necessary packages
from threading import Thread
import sys
import cv2
from queue import Queue


# q = asyncio.Queue(100)


class FileVideoStream:
    def __init__(self, path, queueSize=33):
        # initialize the file video stream along with the boolean
        # used to indicate if the thread should be stopped or not
        self.stream = cv2.VideoCapture(path)
        self.stopped = False
        # initialize the queue used to store frames read from
        # the video file
        self.Q = Queue(maxsize=queueSize)
        self.tracker = Tracker(
            initialization_delay=3,
            distance_function="euclidean",
            hit_counter_max=35,
            filter_factory=OptimizedKalmanFilterFactory(),
            distance_threshold=50,
            past_detections_length=5,
            reid_distance_function=embedding_distance,
            reid_distance_threshold=0.92,
            reid_hit_counter_max=500,
        )
        self.detect = Detections(320, 320, 320, 320, )

    def start(self):
        # start a thread to read frames from the file video stream
        t = Thread(target=self.update, args=())
        t.daemon = True
        t.start()

        return self


    @profile
    def update(self):
        # keep looping infinitely
        while True:
            # if the thread indicator variable is set, stop the
            # thread
            if self.stopped:
                return
            # otherwise, ensure the queue has room in it
            if not self.Q.full():
                # read the next frame from the file
                (grabbed, frame) = self.stream.read()
                # if the `grabbed` boolean is `False`, then we have
                # reached the end of the video file
                if not grabbed:
                    self.stop()
                    return
                # add the frame to the queue

                result = self.detect.yolo_predictions(frame, self.tracker)
                self.Q.put(result)
                # print(self.Q.qsize())

            else:
                print('queue is full')
                time.sleep(0.3)  # Rest for 100ms, we have a full queue

    def read(self):
        # return next frame in the queue
        return self.Q.get()

    def more(self):
        # return True if there are still frames in the queue
        return self.Q.qsize() > 0

    def stop(self):
        # indicate that the thread should be stopped
        self.stopped = True

@profile
def gen_frames(url):
    total_time = time.perf_counter()
    t = FileVideoStream(url).start()
    # t = FileVideoStream('rtsp://admin:admin123@192.168.1.15:554/cam/realmonitor?channel=1&subtype=0').start()
    # t = FileVideoStream('rtsp://admin:admin12345@192.168.1.16:554/cam/realmonitor?channel=1&subtype=0').start()
    # t = FileVideoStream('rtsp://admin:admin12345@192.168.1.152:554/cam/realmonitor?channel=1&subtype=0').start()
    # t = FileVideoStream('rtsp://admin:admin12345@192.168.1.153:554/cam/realmonitor?channel=1&subtype=0').start()
    # todo, this time....
    time.sleep(.5)
    print('generate frames')
    # f = Thread(target=frames, args=())
    # f.daemon = True
    # f.start()
    # frames()23
    # t.tracker.tracked_objects
    tt= 0
    i=0
    while True:
        start_time = time.perf_counter()
        if t.more():

            result = t.read()

            # result = yolo_predictions(frame)
            # if not q.full():
            #     q.put(result)
            # ret, buffer = cv2.imencode('.jpg', result)
            # frame = buffer.tobytes()
            # result = q.get()
            ret, buffer = cv2.imencode('.jpg', result)
            frame = buffer.tobytes()

            end_time = time.perf_counter()
            # print('frames: ', end_time - start_time)
            ti= 1 / (end_time - start_time)
            tt+=ti
            i+=1
            # print("fps",ti,"\n\n")
            # print("avg",tt/i,"\n\n")

            yield (b'--frame\r\n'b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
        else:
            # print('ququ is empty now')
            time.sleep(0.001)
        end_time = time.perf_counter()
        # print('fps: ', end_time - start_time)
        # frame = asyncio.run(frames())
        # print("\n\n", 1 / (end_time - start_time))
        # print('__________________')
        # ret, buffer = cv2.imencode('.jpg', result)
        # frame = buffer.tobytes()
        # end_time = time.perf_counter()



        # print('fps: ', end_time - start_time)
        # print("\n\n", 1 / (end_time - start_time))
        # print('\n\n__________________')



        # yield (b'--frame\r\n'b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
    end_time = time.perf_counter()
    # print('Total_time: ', end_time - total_time)

# @app.route('/video_feed/<url>')
# def video_feed(url):
#     print(url)
#
#     return Response(gen_frames(url), mimetype='multipart/x-mixed-replace; boundary=frame', )

@app.route('/video_feed/<url>')
def video_feed(url):
    print(url)
    return Response(gen_frames(url), mimetype='multipart/x-mixed-replace; boundary=frame', )

@app.route('/')
def index():
    return render_template('yolo.html')


if __name__ == "__main__":
    app.run(debug=False, port=6033, threaded=True)
