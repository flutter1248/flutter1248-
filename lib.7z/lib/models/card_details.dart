import 'package:untitled3/models/enums/card_type.dart';

class CardDetails {
  final String cardNumber;
  final CardType cardType;

  CardDetails(this.cardNumber, this.cardType);
}
