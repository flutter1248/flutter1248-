// ignore_for_file: prefer_const_constructors, avoid_print, prefer_const_literals_to_create_immutables

import 'dart:math';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

// import 'text.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CCTV',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'CCTV'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String detection = 'Detection and Rcoognitions ';
  String unwanted = 'Unwanted Object';
  String vehicle = 'Vehicle detection';
  String behaviour = 'Behavious analysis';
  String tag = '';
  String placeHolder = '';
  List cols = ['PersonName'];

  // late Map <dynamic,dynamic> persons;
  // late Map<dynamic, dynamic> persons;
  var data;

  var dataTablesScreen = false;
  var loading = false;
  List<Widget> allowedWidgets = [];
  late Widget myGridView;
  List modules = <Map<String, dynamic>>[
    {
      'name': "Text",
      'icon': Icons.text_snippet,
      "tag": "T",
      "color": Colors.green
    },
    {'name': "Image", 'icon': Icons.image, "tag": "I", "color": Colors.purple},
    {
      'name': "Video",
      'icon': Icons.video_camera_front,
      "tag": "V",
      "color": Colors.orange
    },
    {
      'name': "Recognition",
      'icon': Icons.person,
      "tag": "V",
      "color": Colors.orange
    },
    {
      'name': "Speech",
      'icon': Icons.multitrack_audio,
      "tag": "S",
      "color": Colors.cyan
    },
    {
      'name': "CCTV",
      'icon': Icons.camera_rounded,
      "tag": "V",
      "color": Colors.orange
    },
  ];

  @override
  Widget build(BuildContext context) {
    allowedWidgets = [];

    for (var e in modules) {
      if (tag == e['tag'] || tag == '') {
        allowedWidgets.add(
          Material(
            color: Colors.blue.shade50,
            child: InkWell(
              onTap: () async {
                // Navigator.push(context,MaterialPageRoute(builder: (context) => DataTables()));

                setState(() {
                  dataTablesScreen = true;
                  loading = true;
                });
                await getData().then((value) {
                  // List cols = ['index','PersonName','Date','camera'];

                  setState(() {
                    data = value;

                    // persons = data['PersonName']; //.toList().toString();
                    loading = false;
                  });
                });
              },
              child: GridTile(
                footer: Container(
                  margin: EdgeInsets.fromLTRB(4, 10, 4, 10),
                  padding: EdgeInsets.all(10),
                  color: e['color'][300],
                  child: Center(
                      child: Text(
                    e['name'],
                    style: TextStyle(color: Colors.white),
                  )),
                ),
                child: Card(
                  elevation: 2,
                  color: e['color'][100],
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(0, 0, 0, 30),
                    child: Icon(
                      e['icon'],
                      size: 150,
                      // color: e['color'][100],
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      }
    }

    myGridView = Expanded(
      child: GridView(
          padding: EdgeInsets.all(20),
          gridDelegate:
              SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3),
          children: allowedWidgets),
    );

    return Scaffold(
      appBar: AppBar(
        title: Center(child: Text(widget.title)),
      ),
      body: Center(
        child: Row(
          children: [
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[

                  Expanded(
                    flex: 1,
                    child: Container(
                      decoration: BoxDecoration(
                          // color: Colors.white,
                          ),
                      width: double.infinity,
                      // height: 900,
                      child: ListView(
                        padding: EdgeInsets.fromLTRB(0, 20, 0, 0),
                        children: [
                          Container(
                            // width: 200,
                            height: 30,
                            color: Colors.blue,
                            child: Center(
                                child: Text(
                              'Modules',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 22),
                            )),
                          ),
                          ListTile(
                            onTap: () {
                              setState(() {
                                tag = 'T';
                              });
                            },
                            title: Text(
                              detection,
                            ),
                            minVerticalPadding: 20,
                            leading: const Icon(
                              Icons.find_replace,
                              size: 30,
                              color: Colors.blue,
                            ),
                          ),
                          ListTile(
                            onTap: () {
                              setState(() {
                                tag = 'T';
                              });
                            },
                            title: Text(
                              detection,
                            ),
                            minVerticalPadding: 20,
                            leading: const Icon(
                              Icons.find_replace,
                              size: 30,
                              color: Colors.blue,
                            ),
                          ),

                          Container(
                            // width: 200,
                            height: 30,
                            color: Colors.blue,
                            child: Center(
                                child: Text(
                              'Filters',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 22),
                            )),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            VerticalDivider(
              color: Colors.blue,
              width: 1,
            ),
            Expanded(
              flex: 4,
              child: Container(
                width: double.infinity,
                color: Colors.blue.shade50,
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 25, 0, 0),
                      child: Text(
                        placeHolder,
                        style: TextStyle(
                            fontSize: 22, fontWeight: FontWeight.bold),
                      ),
                    ),
                    !dataTablesScreen
                        ? myGridView
                        : loading
                            ? Container(
                                child: Container(
                                    child: CircularProgressIndicator(
                                  color: Colors.blue,
                                )),
                              )
                            : Container(
                                width: 600,
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    boxShadow: [BoxShadow()]),
                                // child: Text(persons)
                                child: DataTable(columns: [
                                  ...data.keys.map(
                                    (e) => DataColumn(label: Text(e)),
                                  )
                                ], rows: [
                                  ...data['PersonName'].keys.map((x) => DataRow(cells: [
                                        ...data.keys.map(
                                          (e) => DataCell(
                                              Text(data[e][x].toString())),
                                        )
                                      ],))
                                ]),
                              ),

                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<dynamic> getData() async {
    final response = await http.get(Uri.parse('http://127.0.0.1:5000/getdata'));
    var dat = jsonDecode(response.body.toString());
    print(dat);
    setState(() {
      data = dat;
      // persons = data['PersonName'];/
      loading = false;

    });

    return Future.delayed(Duration(milliseconds: 250),getData);
    // return dat;
    // return "response. body.toString()";
  }
}
