import 'package:flutter/material.dart';
import 'package:flutter_mjpeg/flutter_mjpeg.dart';

class VideoPlayer extends StatefulWidget {
  // bool running;
  String url;
  // VideoPlayer({Key? key, required this.url, this.running=true}) : super(key: key);
  VideoPlayer({Key? key, required this.url}) : super(key: key);

  @override
  State<VideoPlayer> createState() => _VideoPlayerState();
}

class _VideoPlayerState extends State<VideoPlayer> {


  @override
  Widget build(BuildContext context) {

    return Center(
      child:
      Container(
        child: Column(
          children: <Widget>[
            Expanded(
              child: Container(

                child: Center(
                  child:Mjpeg(
                    isLive: true,
                    // isLive: widget.running,
                    error: (context, error, stack) {
                      print(error);
                      print(stack);
                      return Text(error.toString(),
                          style: const TextStyle(color: Colors.red));
                    },
                    stream:widget.url,
                  ),
                ),
              ),
            ),
            // Row(
            //   children: <Widget>[
            //     ElevatedButton(
            //       onPressed: () {
            //         setState(() {
            //           widget.running = true;
            //         });
            //
            //       },
            //       child: const Text('Toggle'),
            //     ),
            //     ElevatedButton(
            //       onPressed: () {
            //         Navigator.of(context).push(MaterialPageRoute(
            //             builder: (context) => Scaffold(
            //               appBar: AppBar(),
            //             )));
            //       },
            //       child: const Text('Push new route'),
            //     ),
            //   ],
            // ),
          ],
        ),
      ),
    );
  }
}
