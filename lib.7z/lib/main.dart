import 'package:untitled3/layout/app_layout.dart';
import 'package:untitled3/models/card_details.dart';
import 'package:untitled3/widgets/video_player.dart';
import 'package:untitled3/models/enums/card_type.dart';
import 'package:untitled3/responsive.dart';
import 'package:untitled3/sections/expense_income_chart.dart';
import 'package:untitled3/sections/latest_transactions.dart';
import 'package:untitled3/sections/statics_by_category.dart';
import 'package:untitled3/sections/upgrade_pro_section.dart';
import 'package:untitled3/sections/your_cards_section.dart';
import 'package:untitled3/styles/styles.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const FintechDasboardApp());
}

class FintechDasboardApp extends StatelessWidget {
  const FintechDasboardApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: Styles.scaffoldBackgroundColor,
        scrollbarTheme: Styles.scrollbarTheme,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int activeTab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: AppLayout(
          content: Row(
            children: [
              // Main Panel
              Expanded(
                flex: 5,
                child: Column(
                  children: [
                                       Expanded(
                                         child: Row(
                                           children: [
                                             Expanded(child: VideoPlayer(url:'http://127.0.0.1:6033/video_feed/1.avi' )),
                                             Expanded(child: VideoPlayer(url:'http://127.0.0.1:6033/video_feed/1.avi' )),
                                             Expanded(child: VideoPlayer(url:'http://127.0.0.1:6033/video_feed/1.avi' )),
                                             Expanded(child: VideoPlayer(url:'http://127.0.0.1:6033/video_feed/1.avi' )),
                                             // Expanded(child: VideoPlayer(url:'http://192.168.18.18:5000/video_feed' )),
                                             // Expanded(child: VideoPlayer(url:'http://192.168.18.18:5000/video_feed' )),
                                             // Expanded(child: VideoPlayer(url:'rtsp://admin:admin123@192.168.1.15:554/cam/realmonitor?channel=1&subtype=0' )),
                                             // Expanded(child: VideoPlayer(url:'rtsp://admin:admin12345@192.168.1.16:554/cam/realmonitor?channel=1&subtype=0' )),
                                             // Expanded(child: VideoPlayer(url:'rtsp://admin:admin12345@192.168.1.152:554/cam/realmonitor?channel=1&subtype=0' )),
                                             // Expanded(child: VideoPlayer(url:'rtsp://admin:admin12345@192.168.1.153:554/cam/realmonitor?channel=1&subtype=0' )),
                                           ],
                                         ),
                                       ),
                    // const Expanded(
                    //   flex: 2,
                    //   child: ExpenseIncomeCharts(),
                    // ),
                    // Expanded(
                    //   child: Padding(
                    //     padding: EdgeInsets.symmetric(
                    //       vertical: Styles.defaultPadding,
                    //     ),
                    //     child: const UpgradeProSection(),
                    //   ),
                    // ),
                    // Expanded(
                    //   flex: 2,
                    //   child: LatestTransactions(),
                    // ),
                  ],
                ),
              ),
              // Right Panel
              // Visibility(
              //   visible: Responsive.isDesktop(context),
              //   child: Expanded(
              //     flex: 2,
              //     child: Padding(
              //       padding: EdgeInsets.only(left: Styles.defaultPadding),
              //       child: Column(
              //         children: [
              //           CardsSection(
              //             cardDetails: [
              //               CardDetails("431421432", CardType.mastercard),
              //               CardDetails("423142231", CardType.mastercard),
              //             ],
              //           ),
              //           const Expanded(
              //             child: StaticsByCategory(),
              //           ),
              //         ],
              //       ),
              //     ),
              //   ),
              // )
            ],
          ),
        ),
      ),
    );
  }
}
